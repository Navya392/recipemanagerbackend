
const { MongoClient } = require("mongodb");
require("dotenv").config();

const uri = process.env.MONGODB_URI;
const dbName = process.env.DB_NAME;

let client;


exports.handler = async (event, context) => {
  if (!client) {
    client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true });
    await client.connect();
  }
  try {debugger
    const db = client.db(dbName);
    const recipesCollection = db.collection("recipes"); // Use the collection name
    const recipes = await recipesCollection.find({}).toArray();

  return {
    statusCode: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',  // Allow all origins (you can restrict it to specific domains later)
      'Access-Control-Allow-Methods': 'GET',  // Allow only GET requests
      'Access-Control-Allow-Headers': 'Content-Type', // Allow Content-Type header
    },
    body: JSON.stringify(recipes),
  };
}
catch (error) {
  console.error('Error fetching recipes:', error);
  return {
    statusCode: 500,
    body: JSON.stringify({ message: 'Internal Server Error' }),
  };
}
};